const fs = require('fs');
const PDFDocument = require('pdfkit');

// Etap 1: Metadane dokumentu
const document = new PDFDocument({
  size: 'B5',
  margin: 50,
  autor:"Szymon"
});

// Etap 2: Nagłówek tekstowy
document.font('media/Lato-Regular.ttf')
  .fontSize(20)
  .text('Zespół Szkół Elektrycznych', { align: 'center' });

document.font('media/Lato-Regular.ttf') 
  .fontSize(16)
  .text('4TP Szymon Rozwoda', { align: 'center' })

// Etap 3: Obraz (logo ZSE)
const logoPath = 'media/zse-logo.png'; 
document.image(logoPath, {
  width: document.page.width * 0.3,
  align: 'left',
});
const linkText = 'więcej';
const linkUrl = 'https://google.pl';
const listItems=['HTML5,CSS3', 'Joomla,WordPress', 'Node.js',{}]
// Etap 4: Tekst z Listą
document.fontSize(14)
  .text('Znane mi technologie Web:', { underline: true, bold: true })
  .list(['HTML5,CSS3', 'Joomla,WordPress', 'Node.js',])
  ;

// Etap 5: Odnośnik URL


document.text(linkText, { link: linkUrl });


// Zapisz dokument do pliku PDF
const outputPath = 'Moj_pdf.pdf';
document.pipe(fs.createWriteStream(outputPath));
document.end();

console.log(`Dokument PDF został wygenerowany i zapisany w: ${outputPath}`);
