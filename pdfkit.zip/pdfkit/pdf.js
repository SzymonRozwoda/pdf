const fs = require('fs');
const PDFDocument = require('pdfkit');

// Etap 1: Metadane dokumentu
const document = new PDFDocument({
  size: 'B5',
  margin: 50,
});

// Etap 2: Nagłówek tekstowy
const fontSizeValue = 20; // Przykład wartości, którą należy sprawdzić

if (!isNaN(fontSizeValue)) {
  document.font('media/Lato-Regular.ttf').fontSize(fontSizeValue).text('Tytuł Dokumentu', { align: 'center' });
} else {
  console.error('Nieprawidłowa wartość dla rozmiaru czcionki');
}

document.font('media/Lato-Regular.ttf')
  .fontSize(16)
  .text('Klasa: [Twoja Klasa]', { align: 'center' })
  .text('Nazwisko i Imię: [Twoje Nazwisko i Imię]', { align: 'center' });

// Etap 3: Obraz (logo ZSE)
const logoPath = 'media/zse-logo.png';
document.image(logoPath, {
  width: document.page.width * 0.3,
  align: 'left',
});

// Etap 4: Tekst z Listą
document.fontSize(14)
  .text('Tekst z odstępem od góry, pogrubiony, podkreślony:', { underline: true, bold: true })
  .list(['Punkt 1', 'Punkt 2', 'Punkt 3']); // Załaduj listę wypunktowaną

// Etap 5: Odnośnik URL
document.text('\nOdnośnik więcej: ', { continued: true })
  .link('https://google.pl', 'https://google.pl');

// Zapisz dokument do pliku PDF
const outputPath = 'output.pdf';
document.pipe(fs.createWriteStream(outputPath));
document.end();

console.log(`Dokument PDF został wygenerowany i zapisany w: ${outputPath}`);
